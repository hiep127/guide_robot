#!/usr/bin/env python


'''
Copyright(c) 2014 Lentin Joseph
'''

import rospy
import sys
import time
import math

from std_msgs.msg import Int16,Int64,Float32,String,Header,UInt64

from SerialDataGateway import SerialDataGateway

class robot_class(object):

	def __init__(self):
		print"starting robot"
		
		self._Counter = 0
		#encoder
		self._left_encoder_value = 0
		self._right_encoder_value = 0

		#motorvalue
		self._left_wheel_speed_ = 0
		self._right_wheel_speed_ = 0

		self._LastUpdate_Microsec = 0
		self._Second_Since_Last_Update = 0

		self.robot_heading = 0

		#Serial
		port=rospy.get_param("~port","/dev/ttyACM0")
		baudRate = int(rospy.get_param("~baudRate",9600))

		
		rospy.loginfo("Starting with serial port: " + port + ", baud rate: " + str(baudRate))
		self._SerialDataGateway = SerialDataGateway(port, baudRate,  self._HandleReceivedLine)
		rospy.loginfo("Started serial communication")

		#Publisher for left and right wheel encoder values
		self._Left_Encoder = rospy.Publisher('lwheel',Int64,queue_size = 10)		
		self._Right_Encoder = rospy.Publisher('rwheel',Int64,queue_size = 10)		


		#Publisher for entire serial data
		self._SerialPublisher = rospy.Publisher('serial', String,queue_size=10)

		#New addon for computing quaternion
		
		self.pi = 3.14159
		self.GyroMeasError = float(self.pi * ( 40 / 180 ))
		self.beta = float(math.sqrt(3 / 4) * self.GyroMeasError)

		self.GyroMeasDrift = float(self.pi * ( 2 / 180 ))
		self.zeta = float(math.sqrt(3 / 4) * self.GyroMeasDrift)


		self.beta = math.sqrt(3 / 4) * self.GyroMeasError

		self.q = [1,0,0,0]

		#######################################################################################################################
#Speed subscriber
		self._left_motor_speed = rospy.Subscriber('left_wheel_speed',Float32,self._Update_Left_Speed)

		self._right_motor_speed = rospy.Subscriber('right_wheel_speed',Float32,self._Update_Right_Speed)


#######################################################################################################################
	def _Update_Left_Speed(self, left_speed):

		self._left_wheel_speed_ = left_speed.data

		rospy.loginfo(left_speed.data)

		speed_message = 's %d %d\r' %(int(self._left_wheel_speed_),int(self._right_wheel_speed_))

		self._WriteSerial(speed_message)

#######################################################################################################################################################3
				

	def _Update_Right_Speed(self, right_speed):

		self._right_wheel_speed_ = right_speed.data

		rospy.loginfo(right_speed.data)

		speed_message = 's %d %d\r' %(int(self._left_wheel_speed_),int(self._right_wheel_speed_))

		self._WriteSerial(speed_message)


#######################################################################################################################

	def _HandleReceivedLine(self,  line):
		self._Counter = self._Counter + 1
		self._SerialPublisher.publish(String(str(self._Counter) + ", in:  " + line))


		if(len(line) > 0):

			lineParts = line.split('\t')
			try:
				if(lineParts[0] == 'e'):
					self._left_encoder_value = long(lineParts[1])
					self._right_encoder_value = long(lineParts[2])

					self._Left_Encoder.publish(self._left_encoder_value)
					self._Right_Encoder.publish(self._right_encoder_value)


#######################################################################################################################
			except:
				rospy.logwarn("Error in Sensor values")
				rospy.logwarn(lineParts)
				pass


#######################################################################################################################

	def _WriteSerial(self, message):
		self._SerialPublisher.publish(String(str(self._Counter) + ", out: " + message))
		self._SerialDataGateway.Write(message)

#######################################################################################################################


	def Start(self):
		rospy.logdebug("Starting")
		self._SerialDataGateway.Start()

################################################################################################################





if __name__ =='__main__':
	rospy.init_node('robot',anonymous=True)
	robot = robot_class()
	try:
		
		robot.Start()	
		rospy.spin()
	except rospy.ROSInterruptException:
		rospy.logwarn("Error in main function")


	

