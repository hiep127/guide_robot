#!/usr/bin/env python


import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal, MoveBaseActionGoal, MoveBaseActionFeedback
from math import radians, degrees
from actionlib_msgs.msg import *
from geometry_msgs.msg import Point 
from std_msgs.msg import Int16,Int64,Float32,String,Header,UInt64

class map_navigation():

	def __init__(self):
		rospy.init_node('navigation', anonymous=False)
		self.xHome = rospy.get_param('~xHome',0.0)
		self.yHome = rospy.get_param('~yHome',0.0)
		self.xA = rospy.get_param('~xA',0.976)
		self.yA = rospy.get_param('~yA',0.988)
		self.xB = rospy.get_param('~xB',-3.0)
		self.yB = rospy.get_param('~yB',-0.7)
		self._loadcell = rospy.Subscriber('loadcell',Int64,self._MoveRobot)
		rospy.Rate(1)
		#rospy.sleep(12)
		self.goalReached = self.moveToGoal(self.xA,self.yA)
	def _MoveRobot(self,data):
		if (data.data == 0):
			self.goalReached = self.moveToGoal(self.xHome, self.yHome)
			if (self.goalReached):
				rospy.loginfo("Home reached!")
				rospy.sleep(12)
				self.goalReached = self.moveToGoal(self.xA, self.yA)
				if (self.goalReached):
					rospy.loginfo("A reached")
				else:
					rospy.loginfo("Hard Luck!")
			else :
				rospy.loginfo("Hard Luck!")
		if (data.data == 1):
			self.goalReached = self.moveToGoal(self.xB, self.yB)
			if (self.goalReached):
				rospy.loginfo("B reached!")
			else :
				rospy.loginfo("Hard Luck!")
	
	def moveToGoal(self,xGoal,yGoal):
		ac = actionlib.SimpleActionClient("move_base", MoveBaseAction)
                pub = rospy.Publisher('move_base/goal', MoveBaseActionGoal, queue_size=1)
		while(not ac.wait_for_server(rospy.Duration.from_sec(5.0))):
			rospy.loginfo("Waiting for the move_base action server to come up")
		

		goal = MoveBaseGoal()
                move_base_goal = MoveBaseActionGoal()
		goal.target_pose.header.frame_id = "map"
		goal.target_pose.header.stamp = rospy.Time.now()
		goal.target_pose.pose.position =  Point(xGoal,yGoal,0)
		goal.target_pose.pose.orientation.x = 0.0
		goal.target_pose.pose.orientation.y = 0.0
		goal.target_pose.pose.orientation.z = 0.0
		goal.target_pose.pose.orientation.w = 1.0

		rospy.loginfo("Sending goal location ...")
                #move_base_goal.goal = goal
		ac.send_goal(goal)
		#pub.publish(move_base_goal)
		wait = ac.wait_for_result()
		if wait:
			return 1
		if not wait:
			return 0
		#rospy.loginfo("Navigating")
  		 

	def shutdown(self):
        # stop turtlebot
        	rospy.loginfo("Quit program")
        	rospy.sleep()

if __name__ == '__main__':
    try:
	
	rospy.loginfo("You have reached the destination")
        map_navigation()
        rospy.spin()
    except rospy.ROSInterruptException:
        rospy.loginfo("map_navigation node terminated.")
		
